import java.util.*

fun main() {
    val input = Scanner(System.`in`)
    val n = input.nextInt()
    var int: Int
    var counter = 0
    var lastInt: Int = input.nextInt()
    for (i in 1 until n) {
        int = input.nextInt()
        if (int != lastInt) counter++
        lastInt = int
    }
    println(counter)
}
